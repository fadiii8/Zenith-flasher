# Zenith's | flasher

**by @whoisfadi**

Android Fastboot + ADB Sideload tool (USB OTG).  
Based on Fairy Flasher / GlassFastboot source — UI redesigned, rebranded.

## Features

- USB OTG Fastboot connect
- Flash single images / ROM zip-tgz
- Fastboot script runner (.bat / .sh)
- ADB Sideload (Custom ROM ZIP)
- Slot A/B control
- Disable verity option
- Console for raw fastboot commands

## Package

- **App name:** Zenith's | flasher  
- **Application ID:** `com.whoisfadi.zenithflasher`  
- **Version:** 1.0  
- **Min SDK:** 26  

## Build without PC (GitHub Actions)

1. Create a new GitHub repository
2. Upload this whole `ZenithFlasher` folder (or the zip)
3. Go to **Actions** tab → run **Build APK** workflow
4. Download the APK from the workflow artifacts

## Build with Android Studio / PC

1. Open this folder in Android Studio
2. Wait for Gradle sync
3. Build → Build APK(s) / Generate Signed APK

## Requirements on phone

- USB OTG support
- Target device in **Fastboot** or **Recovery (ADB sideload)** mode
- OTG cable

## Credit

Original protocol/UI base: Fairy Flasher (@yooitachiijod)  
Rebrand + UI update: @whoisfadi
