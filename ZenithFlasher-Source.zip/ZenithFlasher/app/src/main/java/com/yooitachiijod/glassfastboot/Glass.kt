package com.yooitachiijod.glassfastboot

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Modern dark palette with cyan accent
val Ice = Color(0xFF22D3EE)          // Cyan accent
val Violet = Color(0xFFA78BFA)       // Soft purple
val Pink = Color(0xFFF472B6)         // Soft pink
val Surface = Color(0xFF12121A)      // Card surface
val SurfaceHigh = Color(0xFF1A1A26)  // Elevated surface
val Border = Color(0xFF2A2A3A)       // Subtle border
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val Success = Color(0xFF34D399)
val Danger = Color(0xFFF87171)

@Composable
fun GlassTheme(content: @Composable () -> Unit) =
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ice,
            onPrimary = Color.Black,
            background = Color(0xFF0B0B10),
            surface = Surface,
            onSurface = TextPrimary
        ),
        content = content
    )

/** Dark background with soft animated gradient orbs */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B10))
    ) {
        // Soft cyan orb top-left
        Blob(Ice.copy(alpha = 0.12f), (-40 + 60 * a).dp, (-20).dp, 280.dp)
        // Soft purple orb bottom-right
        Blob(Violet.copy(alpha = 0.10f), (120 - 80 * a).dp, 420.dp, 320.dp)
        // Subtle pink accent
        Blob(Pink.copy(alpha = 0.06f), (40 + 30 * a).dp, 200.dp, 200.dp)
        content()
    }
}

@Composable
private fun Blob(c: Color, x: androidx.compose.ui.unit.Dp, y: androidx.compose.ui.unit.Dp, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier
            .offset(x, y)
            .size(size)
            .blur(80.dp)
            .background(Brush.radialGradient(listOf(c, Color.Transparent)), CircleShape)
    )
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Surface)
            .border(1.dp, Border, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun GlassButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    accent: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    val bg = if (accent) {
        Brush.horizontalGradient(listOf(Ice, Color(0xFF06B6D4)))
    } else {
        Brush.horizontalGradient(listOf(SurfaceHigh, SurfaceHigh))
    }
    val textColor = if (accent) Color.Black else TextPrimary

    Box(
        modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(bg)
            .then(
                if (!accent) Modifier.border(1.dp, Border, shape)
                else Modifier
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = textColor,
            fontSize = 13.sp,
            fontWeight = if (accent) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) Ice.copy(alpha = 0.18f) else SurfaceHigh)
            .border(1.dp, if (selected) Ice.copy(alpha = 0.5f) else Border, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            color = if (selected) Ice else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun GlassTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Surface)
            .border(1.dp, Border, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (on) Ice.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (on) Ice else TextMuted,
                    fontSize = 13.sp,
                    maxLines = 1,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}
